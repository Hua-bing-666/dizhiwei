先读 docs/软件升级包使用说明.md。
离线网页：deliverables/index.html
主机模式：安装 requirements-platform.txt，运行 scripts/启动运行平台.ps1 或 python scripts/run_platform.py。
模型：deliverables/清水试验台架_V1.2.html
附带的 EXE 是 Windows 主机 C 诊断程序，不是 STM32 固件。
无射频、实际串口、能耗或阀门控制验证。
