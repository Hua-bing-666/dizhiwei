解压后打开 deliverables/index.html。正式材料与验证范围见 deliverables/使用说明.md。图表与证据均为未标定模型分析，不是实物或田间数据。
